package com.cg.mypaymentapp.controllers;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.mypaymentapp.beans.Customer;


@Controller
public class URIController {

	@RequestMapping("")
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/createaccount")
	public String getcreateaccountPage() {
		return "createaccountPage";
	}
	@RequestMapping("/showbalance")
	public String getshowBalancePage() {
		return "showBalancePage";
	}
	@RequestMapping("/fundtransfer")
	public String getfundtransferPage() {
		return "fundtransferPage";
	}
	@RequestMapping("/depositbalance")
	public String getdepositamountPage() {
		return "depositamountPage";
	}
	@RequestMapping("/withdrawamount")
	public String getwithdrawamountPage() {
		return "withdrawamountPage";
	}
	
	@ModelAttribute("customer")
		public Customer getCustomer() {
		return new Customer();
	}
	
}