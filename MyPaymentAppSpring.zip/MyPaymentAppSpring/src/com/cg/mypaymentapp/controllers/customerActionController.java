 package com.cg.mypaymentapp.controllers;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.exceptions.InvalidInputException;
import com.cg.mypaymentapp.services.CustomerServices;


@Controller
public class customerActionController {

	@Autowired(required = true)
	private CustomerServices customerServices;

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView registerFaculty(@ModelAttribute("customer") Customer customer) throws Exception
	{
		
		try {
			customerServices.createAccount(customer);
			ModelAndView modelAndView = new ModelAndView("createAccountSuccessPage", "customer", customer);
			return modelAndView;
		} catch (InvalidInputException e) {
			e.printStackTrace();
		}
		return new ModelAndView("errorPage");
	}

	@RequestMapping(value = "/ShowBalance", method = RequestMethod.POST)
	public ModelAndView showbalance(@RequestParam("mobileNo") String mobileNo) throws InvalidInputException{
		Customer customer1 = customerServices.showBalance(mobileNo);
		ModelAndView modelAndView = new ModelAndView("ShowBalanceSuccessPage", "customer1", customer1);
		return modelAndView;
	}
	
	@RequestMapping(value = "/depositbalance", method = RequestMethod.POST)
	public ModelAndView depositAmount (@RequestParam("mobileNo") String mobileNo , @RequestParam("amount") BigDecimal amount )   throws InvalidInputException, SQLException{
		
		Customer customer1 = customerServices.depositAmount( mobileNo,  amount);
		ModelAndView modelAndView = new ModelAndView("ShowBalanceSuccessPage", "customer1", customer1);
		return modelAndView;
	}

	/*@RequestMapping(value = "/update/{id}", method = RequestMethod.GET)
	public ModelAndView edit(@PathVariable int id) {
		try {
			Faculty faculty = facultyServices.getFacultyDetails(id);
			return new ModelAndView("update", "command", faculty);
		} catch (FacultyDetailsNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServicesDownException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new ModelAndView("errorPage");
	}

	@RequestMapping(value = "/editsave", method = RequestMethod.POST)
	public ModelAndView editsave(@ModelAttribute("faculty") Faculty faculty) {
		try {
			faculty = facultyServices.acceptFacultyDetails(faculty);
		} catch (ServicesDownException e) {
			e.printStackTrace();
		}
		return new ModelAndView("redirect:/viewPage");
	}
*/
}
