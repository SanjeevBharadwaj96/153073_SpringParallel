package com.cg.mypaymentapp.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.mypaymentapp.beans.Customer;



public interface WalletRepoImpl extends JpaRepository<Customer, String>{}